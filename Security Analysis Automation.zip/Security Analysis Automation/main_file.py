import brand_monit
import config
import dns_option
import reputation_check
import time

def main_switch(selected_option):
    if selected_option == 0 :
        exit()
    if selected_option == 1 :
        reputation_check.input_validate()
    if selected_option == 2 :
        dns_option.menu()
    if selected_option == 3 :
        brand_monit.menu()
    if selected_option == 4 :
        config.menu()

if __name__ == '__main__' :
    print("\n")
    print("-----------------------------------------")
    print("CYBERSECURITY IP ANALYSIS AUTOMATION TOOL")
    print("-----------------------------------------")
    print("\nThis is Security Operation Center Analysis tool to automate the investigation and validation of possible Indicators of Compromise")
    time.sleep(1)
    while True:
        try:
            config.fetch_api_key()
        except:
            print("\n\nFirst time Configuration Wizard, Initial API Key Configuration")
            config.menu()
            config.fetch_api_key()
            
        print("\nPlease select an option from below : ")
        print("OPTION 1: IP Reputation Check (IPs, Domains, URLs, Hashes, Blacklisted)")
        print("OPTION 2: External DNS & WHOIS Database Lookup Options- APNIC,RIR,ARINA,LIR")
        print("OPTION 3: Public IP Monitoring & Brand Reputation Check")
        print("OPTION 4: Help & Configuration/Re-configuration")
        print("OPTION 0: Exit Tool")
        
        selected_option=int(input())
        if 0 <= selected_option < 4:
            main_switch(selected_option)
        else :
            print("Please select the correct options")
